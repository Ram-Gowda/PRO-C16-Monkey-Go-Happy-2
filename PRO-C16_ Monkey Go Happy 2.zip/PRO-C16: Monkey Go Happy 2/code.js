var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["a6870703-0124-47f7-acff-dbe905f5014c","5ce44e39-12ac-4a66-88cf-a87a0ed6a180","33841f90-7a53-4346-b956-e51d1961959b","f90b9211-02e8-4d3c-b8a4-4a33a3c3e7c0","b7d9f6d6-580d-4d4f-aa4d-b3769d67ada2"],"propsByKey":{"a6870703-0124-47f7-acff-dbe905f5014c":{"name":"monkey","sourceUrl":null,"frameSize":{"x":560,"y":614},"frameCount":10,"looping":true,"frameDelay":2,"version":"JpydBNTV8z5BtxUm5FIVgm7VjsjDuGs0","loadedFromSource":true,"saved":true,"sourceSize":{"x":1680,"y":1842},"rootRelativePath":"assets/a6870703-0124-47f7-acff-dbe905f5014c.png"},"5ce44e39-12ac-4a66-88cf-a87a0ed6a180":{"name":"Banana","sourceUrl":null,"frameSize":{"x":1080,"y":1080},"frameCount":2,"looping":true,"frameDelay":12,"version":"oF47DktoDzaExGd8eeBxGrm8vxDOwPFW","loadedFromSource":true,"saved":true,"sourceSize":{"x":1080,"y":2160},"rootRelativePath":"assets/5ce44e39-12ac-4a66-88cf-a87a0ed6a180.png"},"33841f90-7a53-4346-b956-e51d1961959b":{"name":"Stone","sourceUrl":null,"frameSize":{"x":512,"y":512},"frameCount":2,"looping":true,"frameDelay":12,"version":"eyO32vsJAPlZJzeP2v77Q55hz9Iif9Th","loadedFromSource":true,"saved":true,"sourceSize":{"x":512,"y":1024},"rootRelativePath":"assets/33841f90-7a53-4346-b956-e51d1961959b.png"},"f90b9211-02e8-4d3c-b8a4-4a33a3c3e7c0":{"name":"background","sourceUrl":null,"frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":12,"version":"vubQQxnIHDlrir_ZwmtXvQQ7X8lRI9DK","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/f90b9211-02e8-4d3c-b8a4-4a33a3c3e7c0.png"},"b7d9f6d6-580d-4d4f-aa4d-b3769d67ada2":{"name":"ground_grass_1","sourceUrl":null,"frameSize":{"x":800,"y":198},"frameCount":1,"looping":true,"frameDelay":12,"version":"zT0uUDvXwv2LrEH.T_6rA7UZugtao9mr","categories":["video_games"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":800,"y":198},"rootRelativePath":"assets/b7d9f6d6-580d-4d4f-aa4d-b3769d67ada2.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var backdrop = createSprite(0,0,400,400);
backdrop.setAnimation("background");
backdrop.scale = 2;

var ground = createSprite(400,500,800,10);
ground.setAnimation("ground_grass_1");
ground.scale = 2;
ground.x = ground.width /2;

var monkey = createSprite(90,280,10,10);
monkey.setAnimation("monkey");
monkey.scale = 0.05;

monkey.debug=true;



var ghostGround = createSprite(200,340,400,10);
ghostGround.visible = false;

var count = 0;

var score = 0;

function draw() {
  
  background("white");
  
  if(keyWentDown("space") || keyWentDown("up")){
    monkey.velocityY = -12;
    playSound("assets/category_swish/rope_twirl_new.mp3");
  }
  
  monkey.velocityY = monkey.velocityY + 0.5;
  ground.velocityX = -4;
  
  if (ground.x < -400){
      ground.x = ground.width/2;
    }
    
  monkey.collide(ghostGround);
  
  if(World.frameCount % 80 === 0){
    banana();
  }
  
   if(World.frameCount % 300 === 0){
    rock();
  }
    
  if(bananas.isTouching(monkey)&& monkey.scale < 1){
    score = score +2;
    monkey.scale = monkey.scale + 0.01;
    bananas.destroyEach();
    
    text("Score: "+score+5,130,70);
    
    playSound("assets/category_pop/puzzle_game_ui_pop_01.mp3");
  }
  
  createEdgeSprites();
 
  
  if(monkey.collide(topEdge)){
    score = 0;
    playSound("assets/category_achievements/retro_game_classic_power_up_3.mp3");
  }
  
  if(rocks.isTouching(monkey)){
    score = 0;
    
    monkey.scale = 0.05;
    rocks.destroyEach();
    
    text("Score: "+score,130,70);
    
    playSound("assets/category_alerts/playful_game_error_sound_4.mp3");
  }
  drawSprites();
  
  stroke("black");
  textSize(20);
  fill("black");
  count = Math.ceil(frameCount/frameRate())
  text("Survival Time : "+count,130,30);
  text("Score: "+score,130,70);
  

}

var bananas = createGroup();

var rocks = createGroup();

function banana() {
  var banana = createSprite(400,randomNumber(120,200),10,10);
  banana.setAnimation("Banana");
  banana.scale = 0.08;
  banana.velocityX = -4;
  banana.lifetime = 360;
  
  //banana.debug = true;
  banana.setCollider("circle", 20,0,0);
  bananas.add(banana);
}

function rock() {
  var rock = createSprite(400,300,10,10);
  rock.setAnimation("Stone");
  rock.scale = 0.15;
  rock.velocityX = -4;
  rock.lifetime = 360;
  
  //rock.debug = true;
  rock.setCollider("circle", 20,0,0);
  rocks.add(rock);
}

  

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
